# -*- coding: utf-8 -*-
import threading
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.image import AsyncImage, Image
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Rectangle, PushMatrix, PopMatrix, Rotate, RoundedRectangle
from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.animation import Animation
from kivy.core.window import Window
from kivy.uix.floatlayout import FloatLayout
import webbrowser
import os
import json
import hashlib

# --- COMPOSANT "CARTE D'ACTUALITÉ" ---
class NewsCard(BoxLayout):
    def __init__(self, title, date, description, image_url=None, **kwargs):
        super().__init__(orientation="vertical", size_hint_y=None, spacing=dp(10), padding=dp(15), **kwargs)
        
        with self.canvas.before:
            Color(1, 1, 1, 1) 
            self.bg_rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(10),])
        self.bind(pos=self._update_rect, size=self._update_rect)

        # Titre
        self.add_widget(Label(
            text=f"[b]{title}[/b]",
            markup=True,
            color=(0.1, 0.1, 0.3, 1),
            font_size='18sp',
            size_hint_y=None,
            height=dp(30),
            halign='left',
            valign='middle',
            text_size=(Window.width * 0.75, None)
        ))

        # Date
        self.add_widget(Label(
            text=f"({date})",
            color=(0.5, 0.5, 0.5, 1),
            font_size='12sp',
            size_hint_y=None,
            height=dp(20),
            halign='left',
            valign='middle',
            text_size=(Window.width * 0.75, None)
        ))

        # Description
        desc_label = Label(
            text=description,
            color=(0.2, 0.2, 0.2, 1),
            font_size='15sp',
            size_hint_y=None,
            halign='justify',
            markup=True
        )
        desc_label.bind(width=lambda s, w: s.setter('text_size')(s, (w, None)))
        desc_label.bind(texture_size=lambda s, z: s.setter('height')(s, z[1]))
        self.add_widget(desc_label)

        # --- SECTION IMAGE AVEC LOADER PERSONNALISÉ ---
        # On vérifie si on a une URL OU un chemin de fichier local valide
        
        is_local_file = image_url and os.path.exists(image_url)
        is_web_url = image_url and image_url.startswith("http")

        if is_web_url or is_local_file:
            img_container = FloatLayout(size_hint=(1, None), height=dp(220))
            
            if is_local_file:
                # --- MODE LOCAL : INSTANTANÉ ---
                # On utilise Image (pas Async) pour que ce soit chargé immédiatement
                img = Image(
                    source=image_url,
                    size_hint=(1, 1),
                    pos_hint={'x': 0, 'y': 0},
                    allow_stretch=True,
                    keep_ratio=True,
                    opacity=1 # Déjà visible
                )
                img_container.add_widget(img)
                # Pas besoin de loader ici, c'est instantané
            
            else:
                # --- MODE WEB : AVEC LOADER ---
                img = AsyncImage(
                    source=image_url,
                    size_hint=(1, 1),
                    pos_hint={'x': 0, 'y': 0},
                    allow_stretch=True,
                    keep_ratio=True,
                    opacity=0 
                )
                
                loader = Image(
                    source="assets/icons/loading_wheel.png",
                    size_hint=(None, None),
                    size=(dp(45), dp(45)),
                    pos_hint={'center_x': 0.5, 'center_y': 0.5}
                )

                with loader.canvas.before:
                    PushMatrix()
                    self.rot = Rotate(angle=0)
                with loader.canvas.after:
                    PopMatrix()

                def update_rot_center(instance, value):
                    # On utilise l'origine locale du widget (son propre centre)
                    # au lieu de son centre dans la fenêtre
                    self.rot.origin = (instance.x + instance.width/2, instance.y + instance.height/2)
                    
                loader.bind(pos=update_rot_center, size=update_rot_center)

                anim_rot = Animation(angle=-360, duration=1.2, t='linear')
                anim_rot.repeat = True
                anim_rot.start(self.rot)

                def on_image_loaded(*args):
                    anim_rot.stop(self.rot)
                    Animation(opacity=0, duration=0.2).start(loader)
                    Animation(opacity=1, duration=0.3).start(img)

                img.bind(on_load=on_image_loaded)
                
                img_container.add_widget(img)
                img_container.add_widget(loader)

            self.add_widget(img_container)

        self.bind(minimum_height=self.setter('height'))

    def _update_rect(self, instance, value):
        self.bg_rect.pos = instance.pos
        self.bg_rect.size = instance.size

# --- CLASSE HOMESCREEN --- (Inchangée)
class HomeScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.last_config_hash = None
        self.KIVY_BLUE = (30/255, 58/255, 138/255, 1)

        # Layout principal
        self.main_layout = FloatLayout() 

        self.container = BoxLayout(orientation="vertical")
        with self.container.canvas.before:
            Color(*self.KIVY_BLUE)
            self.rect_bg = Rectangle(pos=self.container.pos, size=self.container.size)
        self.container.bind(pos=self._update_bg, size=self._update_bg)

        self.scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.scroll_content = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(20), padding=[dp(15), dp(10)])
        self.scroll_content.bind(minimum_height=self.scroll_content.setter('height'))

        self.banner = Image(source="assets/banniere.jpg", size_hint=(1, None), height=dp(180), allow_stretch=True, keep_ratio=True)
        self.scroll_content.add_widget(self.banner)

        self.news_layout = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(20))
        self.news_layout.bind(minimum_height=self.news_layout.setter('height'))
        self.scroll_content.add_widget(self.news_layout)

        self.scroll.add_widget(self.scroll_content)
        self.container.add_widget(self.scroll)
        
        # --- AJOUT DU LOADER DE DÉMARRAGE ---
        self.main_loader = Image(
            source="assets/icons/loading_wheel.png",
            size_hint=(None, None),
            size=(dp(50), dp(50)),
            pos_hint={'center_x': 0.5, 'center_y': 0.5},
            opacity=0 # Caché par défaut
        )
        
        with self.main_loader.canvas.before:
            PushMatrix()
            self.main_rot = Rotate(angle=0)
        with self.main_loader.canvas.after:
            PopMatrix()
            
        self.main_loader.bind(center=self._update_rot_origin)
        self.main_anim = Animation(angle=-360, duration=1.2, t='linear')
        self.main_anim.repeat = True

        # Assemblage
        self.main_layout.add_widget(self.container)
        self.main_layout.add_widget(self.main_loader)
        self.add_widget(self.main_layout)

    def _update_rot_origin(self, instance, value):
        self.main_rot.origin = instance.center

    def _update_bg(self, instance, value):
        self.rect_bg.pos = instance.pos
        self.rect_bg.size = instance.size

    def on_enter(self):
        app = App.get_running_app()
        self.update_ui_from_config()

        def background_check():
            if hasattr(app, 'load_remote_config'):
                app.load_remote_config()
                Clock.schedule_once(lambda dt: self.update_ui_from_config(), 0)

        threading.Thread(target=background_check, daemon=True).start()

    def update_ui_from_config(self, *args):
        app = App.get_running_app()
        
        # 1. Vérification de sécurité
        if not hasattr(app, "app_config") or not app.app_config:
            self.show_main_loader(True)
            return False

        # 2. On récupère les données de FCVV (l'étagère)
        fcvv_data = app.app_config.get("fcvv", {})
        
        # 3. On descend dans 'appli' puis dans 'news'
        # On utilise .get() en cascade pour éviter les plantages si une clé manque
        news_list = fcvv_data.get("appli", {}).get("news", [])
        
        # 4. Hashage pour éviter de reconstruire l'interface si rien n'a changé
        
        try:
            # On trie les clés pour que le hash soit stable
            current_hash = hashlib.md5(json.dumps(news_list, sort_keys=True).encode()).hexdigest()
        except:
            current_hash = "error"

        if current_hash == self.last_config_hash:
            return False

        self.last_config_hash = current_hash
        
        # 5. Mise à jour de l'interface
        self.news_layout.clear_widgets()

        if not news_list:
            # Si on a chargé le fichier mais qu'il n'y a pas de news
            self.show_main_loader(False)
            self.news_layout.add_widget(Label(
                text="Aucune actualité pour le moment.", 
                color=(1, 1, 1, 0.6), 
                size_hint_y=None, 
                height=dp(100)
            ))
        else:
            # On cache la roue de chargement et on affiche les cartes
            self.show_main_loader(False)
            for item in news_list:
                card = NewsCard(
                    title=item.get("title", "Info"),
                    date=item.get("date", ""),
                    description=item.get("description", ""),
                    image_url=item.get("image", None)
                )
                self.news_layout.add_widget(card)
        
        return True

    def show_main_loader(self, show):
        if show and self.main_loader.opacity == 0:
            self.main_loader.opacity = 1
            self.main_anim.start(self.main_rot)
        elif not show and self.main_loader.opacity == 1:
            self.main_loader.opacity = 0
            self.main_anim.stop(self.main_rot)