# -*- coding: utf-8 -*-
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, RoundedRectangle
from kivy.app import App
from kivy.metrics import dp
from kivy.core.window import Window
import json
import hashlib

class EffectifScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.last_config_hash = None
        self.current_team_index = 0
        self.KIVY_BLUE = (30/255, 58/255, 138/255, 1)

        self.main_layout = BoxLayout(orientation="vertical")
        with self.main_layout.canvas.before:
            Color(*self.KIVY_BLUE)
            self.rect_bg = RoundedRectangle(pos=self.main_layout.pos, size=self.main_layout.size)
        self.main_layout.bind(pos=self._update_bg, size=self._update_bg)

        # 1. Sélecteur d'équipe (Haut)
        self.team_selector = BoxLayout(size_hint_y=None, height=dp(55), spacing=dp(5), padding=dp(5))
        self.main_layout.add_widget(self.team_selector)

        # 2. Zone Tableau
        self.scroll = ScrollView(size_hint=(1, 1))
        self.table_container = BoxLayout(orientation="vertical", size_hint_y=None, padding=dp(10), spacing=dp(5))
        self.table_container.bind(minimum_height=self.table_container.setter('height'))
        
        self.scroll.add_widget(self.table_container)
        self.main_layout.add_widget(self.scroll)
        self.add_widget(self.main_layout)

    def _update_bg(self, instance, value):
        self.rect_bg.pos = instance.pos
        self.rect_bg.size = instance.size

    def on_enter(self):
        self.update_ui_from_config()

    def update_ui_from_config(self, *args):
        app = App.get_running_app()
        all_effectifs = app.app_config.get("fcvv", {}).get("appli", {}).get("effectifs", [])
        
        if not all_effectifs:
            return

        current_hash = hashlib.md5(json.dumps(all_effectifs, sort_keys=True).encode()).hexdigest()
        if current_hash == self.last_config_hash:
            return
        self.last_config_hash = current_hash

        # Mise à jour des boutons d'onglets
        self.team_selector.clear_widgets()
        for i, eff_data in enumerate(all_effectifs):
            is_active = (i == self.current_team_index)
            btn = Button(
                text=eff_data.get("equipe_nom", "Équipe"),
                size_hint_x=None, width=dp(130),
                background_normal='',
                background_color=(0.97, 0.93, 0.25, 1) if is_active else (1, 1, 1, 0.1),
                color=(0, 0, 0, 1) if is_active else (1, 1, 1, 1),
                bold=is_active
            )
            btn.bind(on_release=lambda x, idx=i: self.switch_team(idx))
            self.team_selector.add_widget(btn)

        self.render_table(all_effectifs[self.current_team_index])

    def switch_team(self, index):
        self.current_team_index = index
        self.last_config_hash = None
        self.update_ui_from_config()

    def render_table(self, data):
        self.table_container.clear_widgets()
        
        # --- HEADER DU TABLEAU ---
        header = GridLayout(cols=5, size_hint_y=None, height=dp(40))
        # Répartition des largeurs : N°, Nom/Prénom, Naissance, Poste, Cap
        cols_widths = [0.12, 0.38, 0.25, 0.15, 0.10]
        titles = ["N°", "Joueur", "Né(e) le", "Poste", ""]
        
        for i, title in enumerate(titles):
            header.add_widget(Label(text=title, bold=True, font_size='14sp', size_hint_x=cols_widths[i]))
        self.table_container.add_widget(header)

        # --- LISTE DES JOUEURS ---
        for j in data.get("joueurs", []):
            row = GridLayout(cols=5, size_hint_y=None, height=dp(45), padding=[dp(5), 0])
            
            # Couleur de fond alternée ou spéciale pour capitaine
            is_cap = j.get("capitaine", False)
            bg_color = (0.97, 0.93, 0.25, 0.15) if is_cap else (1, 1, 1, 0.05)
            
            with row.canvas.before:
                Color(*bg_color)
                self.row_rect = RoundedRectangle(pos=row.pos, size=row.size, radius=[dp(5)])
            
            def update_row(inst, val): inst.canvas.before.children[-1].pos = inst.pos; inst.canvas.before.children[-1].size = inst.size
            row.bind(pos=update_row, size=update_row)

            # N° Maillot
            row.add_widget(Label(text=str(j.get("numero", "-")), size_hint_x=cols_widths[0], color=(0.97, 0.93, 0.25, 1), bold=True))
            
            # Nom Prénom
            nom_complet = f"{j.get('nom', '').upper()} {j.get('prenom', '')}"
            row.add_widget(Label(text=nom_complet, size_hint_x=cols_widths[1], halign='left', text_size=(Window.width*0.35, None)))
            
            # Date de Naissance
            row.add_widget(Label(text=j.get("naissance", "-"), size_hint_x=cols_widths[2], font_size='13sp'))
            
            # Poste
            row.add_widget(Label(text=j.get("poste", "-"), size_hint_x=cols_widths[3], font_size='12sp', color=(0.8, 0.8, 0.8, 1)))

            # Mention Capitaine (Brassard)
            cap_text = "[color=F7EC3F]©[/color]" if is_cap else ""
            row.add_widget(Label(text=cap_text, markup=True, size_hint_x=cols_widths[4], font_size='18sp', bold=True))

            self.table_container.add_widget(row)