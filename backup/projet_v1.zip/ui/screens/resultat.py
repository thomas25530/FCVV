# -*- coding: utf-8 -*-
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, RoundedRectangle
from kivy.app import App
from kivy.metrics import dp
from kivy.core.window import Window
import json
import hashlib

# --- COMPOSANT LIGNE DE RÉSULTAT ---
class ResultRow(BoxLayout):
    def __init__(self, match_data, **kwargs):
        # On utilise une orientation verticale pour mettre les buteurs sous le score
        super().__init__(orientation="vertical", size_hint_y=None, padding=[dp(10), dp(5)], **kwargs)
        
        # Calcul de la hauteur : plus grand si il y a des buteurs
        self.buteurs = match_data.get('buteurs', "")
        self.height = dp(75) if self.buteurs else dp(50)

        # Couleurs selon l'issue
        issue = match_data.get('issue', 'N').upper()
        colors = {"V": (0.1, 0.8, 0.1, 1), "D": (0.8, 0.1, 0.1, 1), "N": (0.6, 0.6, 0.6, 1)}
        res_color = colors.get(issue, (1, 1, 1, 1))

        # --- Ligne Principale (Équipes - Score - Issue) ---
        main_line = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(35))
        
        # Équipes
        teams_txt = f"{match_data.get('equipeA', '')} - {match_data.get('equipeB', '')}"
        main_line.add_widget(Label(
            text=teams_txt, halign='left', font_size='14sp',
            text_size=(Window.width * 0.55, None)
        ))

        # Score
        score_txt = f"{match_data.get('scoreA', '0')} - {match_data.get('scoreB', '0')}"
        main_line.add_widget(Label(
            text=f"[b]{score_txt}[/b]", markup=True, size_hint_x=None, width=dp(60), font_size='16sp'
        ))

        # Issue (V, D, N)
        main_line.add_widget(Label(
            text=issue, size_hint_x=None, width=dp(30), color=res_color, bold=True, font_size='16sp'
        ))

        self.add_widget(main_line)

        # --- Ligne des Buteurs (si présente) ---
        if self.buteurs:
            buteurs_label = Label(
                text=f"[i]({self.buteurs})[/i]",
                markup=True,
                color=(0.7, 0.7, 0.7, 1),
                font_size='11sp',
                halign='center',
                size_hint_y=None,
                height=dp(20),
                text_size=(Window.width * 0.8, None)
            )
            self.add_widget(buteurs_label)

# --- ÉCRAN DES RÉSULTATS ---
class ResultatScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.last_config_hash = None
        self.KIVY_BLUE = (30/255, 58/255, 138/255, 1)

        self.layout = BoxLayout(orientation="vertical")
        with self.layout.canvas.before:
            Color(*self.KIVY_BLUE)
            self.rect_bg = RoundedRectangle(pos=self.layout.pos, size=self.layout.size)
        self.layout.bind(pos=self._update_bg, size=self._update_bg)

        self.scroll = ScrollView(size_hint=(1, 1))
        self.container = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(10), padding=dp(15))
        self.container.bind(minimum_height=self.container.setter('height'))

        self.scroll.add_widget(self.container)
        self.layout.add_widget(self.scroll)
        self.add_widget(self.layout)

    def _update_bg(self, instance, value):
        self.rect_bg.pos = instance.pos
        self.rect_bg.size = instance.size

    def on_enter(self):
        self.update_ui_from_config()

    def update_ui_from_config(self, *args):
        app = App.get_running_app()
        if not hasattr(app, "app_config"): return

        res_data = app.app_config.get("fcvv", {}).get("appli", {}).get("resultats", {})
        if not res_data: return

        current_hash = hashlib.md5(json.dumps(res_data, sort_keys=True).encode()).hexdigest()
        if current_hash == self.last_config_hash: return
        self.last_config_hash = current_hash

        self.container.clear_widgets()

        # Date du weekend
        self.container.add_widget(Label(
            text=f"[b]WEEKEND DU {res_data.get('date_weekend', '').upper()}[/b]",
            markup=True, font_size='18sp', color=(0.97, 0.93, 0.25, 1),
            size_hint_y=None, height=dp(50)
        ))

        for cat in res_data.get("categories", []):
            # Catégorie (SENIORS, JEUNES...)
            self.container.add_widget(Label(
                text=f"[b]{cat.get('nom', '').upper()}[/b]", markup=True,
                font_size='16sp', size_hint_y=None, height=dp(40), halign='left', text_size=(Window.width*0.9, None)
            ))

            for sub in cat.get("sous_categories", []):
                # Sous-catégorie (Masculin, Féminin...)
                self.container.add_widget(Label(
                    text=f"  {sub.get('nom', '')}", color=(0.8, 0.8, 0.8, 1),
                    size_hint_y=None, height=dp(30), halign='left', text_size=(Window.width*0.9, None)
                ))

                # Matchs
                for match in sub.get("matchs", []):
                    self.container.add_widget(ResultRow(match))
                
                self.container.add_widget(BoxLayout(size_hint_y=None, height=dp(10)))