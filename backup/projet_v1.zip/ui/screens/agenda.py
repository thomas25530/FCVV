# -*- coding: utf-8 -*-
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, RoundedRectangle
from kivy.app import App
from kivy.metrics import dp
from kivy.core.window import Window
import json
import hashlib

# --- COMPOSANT "CARTE DE MATCH" ---
class MatchCard(BoxLayout):
    def __init__(self, match_data, **kwargs):
        super().__init__(orientation="vertical", size_hint_y=None, spacing=dp(5), padding=dp(15), **kwargs)
        
        # Hauteur fixe pour une carte de match
        self.height = dp(115)
        
        with self.canvas.before:
            # Fond blanc très léger pour détacher la carte du fond bleu
            Color(1, 1, 1, 0.07) 
            self.bg_rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(10)])
        self.bind(pos=self._update_rect, size=self._update_rect)

        # 1. Niveau et Date/Heure (ex: Régional 2 • 26/04 à 15:00)
        info = f"[color=F7EC3F][b]{match_data.get('niveau', '')}[/b][/color]  •  {match_data.get('date', '')} à {match_data.get('heure', '')}"
        self.add_widget(Label(
            text=info, markup=True, font_size='13sp', size_hint_y=None, height=dp(20), 
            halign='left', text_size=(Window.width * 0.85, None)
        ))

        # 2. Le Match (Equipe A vs Equipe B)
        teams = f"{match_data.get('equipeA', '')}   [color=888888]vs[/color]   {match_data.get('equipeB', '')}"
        self.add_widget(Label(
            text=f"[b]{teams}[/b]", markup=True, font_size='16sp', size_hint_y=None, 
            height=dp(30), halign='center'
        ))

        # 3. Le Lieu
        self.add_widget(Label(
            text=f"[i]{match_data.get('lieu', '')}[/i]", markup=True, color=(0.7, 0.7, 0.7, 1), 
            font_size='12sp', size_hint_y=None, height=dp(20), 
            halign='left', text_size=(Window.width * 0.85, None)
        ))

    def _update_rect(self, instance, value):
        self.bg_rect.pos = instance.pos
        self.bg_rect.size = instance.size

# --- CLASSE PRINCIPALE AGENDA ---
class AgendaScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.last_config_hash = None
        self.KIVY_BLUE = (30/255, 58/255, 138/255, 1)

        # Layout de base
        self.layout = BoxLayout(orientation="vertical")
        with self.layout.canvas.before:
            Color(*self.KIVY_BLUE)
            self.rect_bg = RoundedRectangle(pos=self.layout.pos, size=self.layout.size)
        self.layout.bind(pos=self._update_bg, size=self._update_bg)

        # Zone de défilement
        self.scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.container = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(12), padding=[dp(15), dp(20)])
        self.container.bind(minimum_height=self.container.setter('height'))

        self.scroll.add_widget(self.container)
        self.layout.add_widget(self.scroll)
        self.add_widget(self.layout)

    def _update_bg(self, instance, value):
        self.rect_bg.pos = instance.pos
        self.rect_bg.size = instance.size

    def on_enter(self):
        """Rafraîchit l'affichage à chaque fois qu'on arrive sur l'onglet"""
        self.update_ui_from_config()

    def update_ui_from_config(self, *args):
        app = App.get_running_app()
        if not hasattr(app, "app_config"):
            return

        # --- ACCÈS À LA CLÉ FCVV ---
        fcvv_data = app.app_config.get("fcvv", {})
        agenda_data = fcvv_data.get("appli", {}).get("agenda", {})

        if not agenda_data:
            self.container.clear_widgets()
            self.container.add_widget(Label(text="Aucun match programmé", color=(1,1,1,0.5), size_hint_y=None, height=dp(100)))
            return

        # Hashage pour éviter de reconstruire inutilement si le YAML n'a pas bougé
        try:
            current_hash = hashlib.md5(json.dumps(agenda_data, sort_keys=True).encode()).hexdigest()
        except:
            current_hash = "error"

        if current_hash == self.last_config_hash:
            return

        self.last_config_hash = current_hash
        self.container.clear_widgets()

        # 1. Titre Date du Weekend (ex: Samedi 25 & Dimanche 26...)
        self.container.add_widget(Label(
            text=f"[b]{agenda_data.get('date_weekend', '').upper()}[/b]",
            markup=True, font_size='19sp', color=(0.97, 0.93, 0.25, 1),
            size_hint_y=None, height=dp(60)
        ))

        # 2. Boucle sur les Catégories (Seniors, Jeunes)
        for cat in agenda_data.get("categories", []):
            # Header de catégorie (ex: SENIORS)
            self.container.add_widget(Label(
                text=f"[b]{cat.get('nom', '').upper()}[/b]", markup=True,
                font_size='18sp', size_hint_y=None, height=dp(45), 
                halign='left', text_size=(Window.width * 0.9, None)
            ))

            # Boucle sur les Sous-Catégories (Masculin, Féminin)
            for sub in cat.get("sous_categories", []):
                # Sous-titre de section
                self.container.add_widget(Label(
                    text=f"[color=CCCCCC]Section {sub.get('nom', '')}[/color]", markup=True,
                    font_size='14sp', size_hint_y=None, height=dp(30), 
                    halign='left', text_size=(Window.width * 0.9, None)
                ))

                # Affichage des Matchs de cette section
                for match in sub.get("matchs", []):
                    self.container.add_widget(MatchCard(match_data=match))
                
                # Petit espace de respiration
                self.container.add_widget(BoxLayout(size_hint_y=None, height=dp(10)))

        return True