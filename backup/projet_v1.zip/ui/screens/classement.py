# -*- coding: utf-8 -*-
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, RoundedRectangle
from kivy.app import App
from kivy.metrics import dp
from kivy.core.window import Window
import json
import hashlib

class ClassementScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.last_config_hash = None
        self.current_team_index = 0
        self.KIVY_BLUE = (30/255, 58/255, 138/255, 1)

        self.main_layout = BoxLayout(orientation="vertical")
        with self.main_layout.canvas.before:
            Color(*self.KIVY_BLUE)
            self.rect_bg = RoundedRectangle(pos=self.main_layout.pos, size=self.main_layout.size)
        self.main_layout.bind(pos=self._update_bg, size=self._update_bg)

        # 1. Sélecteur d'équipe (Haut)
        self.team_selector = BoxLayout(size_hint_y=None, height=dp(55), spacing=dp(5), padding=dp(5))
        self.main_layout.add_widget(self.team_selector)

        # 2. Zone d'infos (Journée / MAJ)
        self.info_bar = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(30), padding=[dp(15), 0])
        self.main_layout.add_widget(self.info_bar)

        # 3. Zone Tableau
        self.scroll = ScrollView(size_hint=(1, 1))
        self.table_container = BoxLayout(orientation="vertical", size_hint_y=None, padding=dp(10))
        self.table_container.bind(minimum_height=self.table_container.setter('height'))
        
        self.scroll.add_widget(self.table_container)
        self.main_layout.add_widget(self.scroll)
        self.add_widget(self.main_layout)

    def _update_bg(self, instance, value):
        self.rect_bg.pos = instance.pos
        self.rect_bg.size = instance.size

    def on_enter(self):
        self.update_ui_from_config()

    def update_ui_from_config(self, *args):
        app = App.get_running_app()
        all_classements = app.app_config.get("fcvv", {}).get("appli", {}).get("classements", [])
        
        if not all_classements:
            return

        # Hash pour éviter de recharger si rien ne change
        current_hash = hashlib.md5(json.dumps(all_classements, sort_keys=True).encode()).hexdigest()
        if current_hash == self.last_config_hash:
            return
        self.last_config_hash = current_hash

        # Mise à jour du sélecteur
        self.team_selector.clear_widgets()
        for i, class_data in enumerate(all_classements):
            is_active = (i == self.current_team_index)
            btn = Button(
                text=class_data.get("equipe_nom", "Équipe"),
                size_hint_x=None, width=dp(130),
                background_normal='',
                background_color=(0.97, 0.93, 0.25, 1) if is_active else (1, 1, 1, 0.1),
                color=(0, 0, 0, 1) if is_active else (1, 1, 1, 1),
                bold=is_active
            )
            btn.bind(on_release=lambda x, idx=i: self.switch_team(idx))
            self.team_selector.add_widget(btn)

        self.render_table(all_classements[self.current_team_index])

    def switch_team(self, index):
        self.current_team_index = index
        self.last_config_hash = None # Force le refresh
        self.update_ui_from_config()

    def render_table(self, data):
        # 1. Mise à jour de la barre d'infos
        self.info_bar.clear_widgets()
        txt_info = f"[b]{data.get('journee', '-')}[/b]  •  MAJ : {data.get('maj', '-')}"
        self.info_bar.add_widget(Label(text=txt_info, markup=True, font_size='13sp', halign='left', text_size=(Window.width*0.9, None)))

        # 2. Nettoyage tableau
        self.table_container.clear_widgets()
        
        # Header colonnes
        header = GridLayout(cols=12, size_hint_y=None, height=dp(40))
        cols_widths = [0.08, 0.28, 0.08, 0.06, 0.06, 0.06, 0.06, 0.06, 0.06, 0.06, 0.06, 0.08]
        titles = ["Rg", "Equipe", "Pts", "J", "G", "N", "P", "F", "Bp", "Bc", "Pé", "Diff"]
        
        for i, title in enumerate(titles):
            header.add_widget(Label(text=title, bold=True, font_size='10sp', size_hint_x=cols_widths[i]))
        self.table_container.add_widget(header)

        # Lignes
        for entry in data.get("tableau", []):
            row = GridLayout(cols=12, size_hint_y=None, height=dp(35))
            is_club = "Vercel" in entry.get("equipe", "")
            
            with row.canvas.before:
                Color(0.97, 0.93, 0.25, 0.2) if is_club else Color(1, 1, 1, 0.05)
                self.row_rect = RoundedRectangle(pos=row.pos, size=row.size, radius=[dp(3)])
            
            # Pour que le rectangle suive le mouvement (Kivy trick)
            def update_row(inst, val): inst.canvas.before.children[-1].pos = inst.pos; inst.canvas.before.children[-1].size = inst.size
            row.bind(pos=update_row, size=update_row)

            fields = ["rang", "equipe", "pts", "j", "g", "n", "p", "f", "bp", "bc", "pe", "diff"]
            for i, field in enumerate(fields):
                row.add_widget(Label(
                    text=str(entry.get(field, "0")),
                    font_size='11sp',
                    size_hint_x=cols_widths[i],
                    color=(1, 1, 0.6, 1) if is_club else (1, 1, 1, 1),
                    bold=is_club
                ))
            
            self.table_container.add_widget(row)