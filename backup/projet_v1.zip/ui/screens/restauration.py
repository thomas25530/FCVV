# -*- coding: utf-8 -*-
import threading
import hashlib
import webbrowser
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.clock import Clock
from kivy.app import App
from kivy.graphics import Color, Rectangle, PushMatrix, PopMatrix, Rotate
from kivy.metrics import dp
from kivy.animation import Animation
from kivy.properties import NumericProperty
from kivy.uix.widget import Widget
from kivy.core.window import Window

class LoadingSpinner(Image):
    angle = NumericProperty(0)
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.source = "assets/icons/loading_wheel.png" 
        self.size_hint = (None, None)
        self.size = (dp(50), dp(50))
        self.pos_hint = {'center_x': 0.5}
        with self.canvas.before:
            PushMatrix()
            self.rot = Rotate(angle=0, origin=self.center)
        with self.canvas.after:
            PopMatrix()
        self.bind(pos=self._update_rotate_origin, size=self._update_rotate_origin)
        self.anim = Animation(angle=-360, duration=1.5)
        self.anim.repeat = True
        self.anim.start(self)
    def _update_rotate_origin(self, *args):
        self.rot.origin = self.center
    def on_angle(self, item, value):
        self.rot.angle = value

class RestaurationScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        app = App.get_running_app()
        self.is_apk = getattr(app, 'generate_APK', False)
        self.KIVY_BLUE = (30/255, 58/255, 138/255, 1)
        self.YELLOW = (247/255, 236/255, 63/255, 1)
        self.current_tab = "boissons" # Onglet par défaut
        
        # Fond bleu
        with self.canvas.before:
            Color(*self.KIVY_BLUE)
            self.rect_bg = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._update_rect, size=self._update_rect)

        self.main_layout = BoxLayout(orientation='vertical')
        
        # 1. SÉLECTEUR D'ONGLETS (Style cohérent)
        self.tab_bar = BoxLayout(size_hint_y=None, height=dp(55), spacing=dp(5), padding=dp(5))
        self.main_layout.add_widget(self.tab_bar)

        # 2. ZONE DE CONTENU (ScrollView)
        self.scroll = ScrollView(do_scroll_x=False)
        self.content_layout = BoxLayout(orientation='vertical', padding=dp(20), spacing=dp(10), size_hint_y=None)
        self.content_layout.bind(minimum_height=self.content_layout.setter('height'))
        self.scroll.add_widget(self.content_layout)
        
        self.main_layout.add_widget(self.scroll)
        self.add_widget(self.main_layout)

    def _update_rect(self, instance, value):
        self.rect_bg.pos = instance.pos
        self.rect_bg.size = instance.size

    def create_section_title(self, text):
        return Label(
            text=f"[b]{text.upper()}[/b]", 
            markup=True, font_size='20sp', color=self.YELLOW,
            size_hint_y=None, height=dp(50), halign='left', text_size=(Window.width*0.9, None)
        )

    def create_item_row(self, name, price, is_sold_out, deposit, user_size):
        app = App.get_running_app()
        tr = app._ if hasattr(app, '_') else lambda x: x
        has_deposit = deposit is not None and str(deposit).strip() not in ["", "0"]
        
        h_row = dp(65) if has_deposit else dp(45)
        row = BoxLayout(orientation='horizontal', size_hint_y=None, height=h_row, padding=[0, dp(5)])
        
        # Nom et Consigne
        display_name = f"[b]{name}[/b]"
        if is_sold_out:
            display_name += f"  [color=ff0000]({tr('sold_out')})[/color]"
        if has_deposit:
            display_name += f"\n[size={int(user_size*0.8)}sp][color=aaaaaa]{tr('deposit')}: {deposit} Jtn[/color][/size]"
            
        name_label = Label(text=display_name, markup=True, font_size=f"{user_size}sp", halign='left', valign='top', size_hint_x=0.75)
        name_label.bind(size=lambda s, v: setattr(s, 'text_size', (v[0], v[1])))
        
        # Prix
        price_label = Label(text=f"{price} Jtn", markup=True, font_size=f"{user_size}sp", halign='right', valign='top', size_hint_x=0.25, color=(0.9, 0.9, 0.9, 1))
        price_label.bind(size=lambda s, v: setattr(s, 'text_size', (v[0], v[1])))
        
        row.add_widget(name_label)
        row.add_widget(price_label)
        return row

    def switch_tab(self, tab_name):
        self.current_tab = tab_name
        self.update_ui_from_config()

    def on_enter(self):
        self.update_ui_from_config()
        app = App.get_running_app()
        def background_check():
            if hasattr(app, 'load_remote_config'):
                app.load_remote_config()
                Clock.schedule_once(lambda dt: self.update_ui_from_config(), 0)
        threading.Thread(target=background_check, daemon=True).start()

    def update_ui_from_config(self, *args):
        app = App.get_running_app()
        if not hasattr(app, 'app_config') or not app.app_config:
            return

        tr = app._ if hasattr(app, '_') else lambda x: x
        lang = app.config.get('User', 'langue') if hasattr(app, 'config') else 'Français'
        user_size = app.config.getint('User', 'font_size_factor', fallback=18) if hasattr(app, 'config') else 18

        # --- MISE À JOUR DE LA BARRE D'ONGLETS ---
        self.tab_bar.clear_widgets()
        tabs = [("boissons", tr("tab_boissons")), ("nourriture", tr("tab_nourriture"))]
        for tid, tlabel in tabs:
            is_active = (self.current_tab == tid)
            btn = Button(
                text=tlabel, background_normal='',
                background_color=(0.97, 0.93, 0.25, 1) if is_active else (1, 1, 1, 0.1),
                color=(0, 0, 0, 1) if is_active else (1, 1, 1, 1),
                bold=is_active
            )
            btn.bind(on_release=lambda x, t=tid: self.switch_tab(t))
            self.tab_bar.add_widget(btn)

        # --- RECONSTRUCTION DU CONTENU ---
        self.content_layout.clear_widgets()
        restau_data = app.app_config.get("tournoi", {}).get("appli", {}).get("restauration", {})

        def fill_section(section_title, items_list):
            if not items_list: return
            self.content_layout.add_widget(self.create_section_title(section_title))
            for item in items_list:
                name = item.get('nom_en') if lang == 'English' and 'nom_en' in item else item.get('nom', '???')
                self.content_layout.add_widget(self.create_item_row(
                    name, str(item.get("prix", "0")), item.get('epuise', False), item.get('consigne'), user_size
                ))
            self.content_layout.add_widget(Widget(size_hint_y=None, height=dp(15)))

        if self.current_tab == "boissons":
            b_data = restau_data.get("boissons", {})
            fill_section(tr("title_alcool"), b_data.get("avec_alcool", []))
            fill_section(tr("title_soft"), b_data.get("sans_alcool", []))
        else:
            n_data = restau_data.get("nourriture", {})
            fill_section(tr("title_sale"), n_data.get("sale", []))
            fill_section(tr("title_sucre"), n_data.get("sucre", []))