# -*- coding: utf-8 -*-
import threading
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.image import AsyncImage, Image
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Rectangle, PushMatrix, PopMatrix, Rotate, RoundedRectangle
from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.animation import Animation
from kivy.core.window import Window
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.modalview import ModalView
import webbrowser
import os
import json
import hashlib

# --- APERÇU DE L'IMAGE EN PLEIN ÉCRAN ---
class ImagePreview(ModalView):
    def __init__(self, img_source, **kwargs):
        super().__init__(**kwargs)
        self.background = ""
        self.background_color = (0, 0, 0, 0.9)
        self.size_hint = (1, 1)

        layout = FloatLayout()
        full_img = AsyncImage(
            source=img_source,
            size_hint=(0.95, 0.95),
            pos_hint={'center_x': 0.5, 'center_y': 0.5},
            allow_stretch=True,
            keep_ratio=True
        )
        layout.add_widget(full_img)
        self.add_widget(layout)
        
    def on_touch_down(self, touch):
        self.dismiss()
        return True

# --- CARTE D'ACTUALITÉ ---
class NewsCard(BoxLayout):
    def __init__(self, title, date, description, image_url=None, **kwargs):
        super().__init__(orientation="vertical", size_hint_y=None, spacing=dp(10), padding=dp(15), **kwargs)
        
        app = App.get_running_app()
        user_font_size = 18  
        if app and hasattr(app, 'config') and app.config.has_section('User'):
            try: user_font_size = app.config.getint('User', 'font_size_factor')
            except: pass
        
        with self.canvas.before:
            Color(1, 1, 1, 1) 
            self.bg_rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(10),])
        self.bind(pos=self._update_rect, size=self._update_rect)

        # Titre
        self.add_widget(Label(
            text=f"[b]{title}[/b]", markup=True, color=(0.1, 0.1, 0.3, 1),
            font_size=f"{user_font_size}sp", size_hint_y=None, height=dp(30),
            halign='left', valign='middle', text_size=(Window.width * 0.8, None)
        ))

        # Date
        self.add_widget(Label(
            text=f"({date})", color=(0.5, 0.5, 0.5, 1),
            font_size=f"{user_font_size - 6}sp", size_hint_y=None, height=dp(20),
            halign='left', valign='middle', text_size=(Window.width * 0.8, None)
        ))

        # Description
        desc_label = Label(
            text=description, color=(0.2, 0.2, 0.2, 1),
            font_size=f"{user_font_size - 3}sp", size_hint_y=None,
            halign='justify', markup=True
        )
        desc_label.bind(width=lambda s, w: s.setter('text_size')(s, (w, None)))
        desc_label.bind(texture_size=lambda s, z: s.setter('height')(s, z[1]))
        self.add_widget(desc_label)

        # Section Image
        if image_url:
            is_local = os.path.exists(image_url)
            img_container = FloatLayout(size_hint=(1, None), height=dp(220))
            img_class = Image if is_local else AsyncImage
            
            img = img_class(
                source=image_url, size_hint=(1, 1), pos_hint={'x': 0, 'y': 0},
                allow_stretch=True, keep_ratio=True, opacity=1 if is_local else 0
            )

            def on_img_click(instance, touch):
                if instance.collide_point(*touch.pos):
                    ImagePreview(img_source=instance.source).open()
                    return True
                return False
            img.bind(on_touch_down=on_img_click)
            img_container.add_widget(img)

            if not is_local:
                loader = Image(
                    source="assets/icons/loading_wheel.png", size_hint=(None, None),
                    size=(dp(40), dp(40)), pos_hint={'center_x': 0.5, 'center_y': 0.5}
                )
                with loader.canvas.before:
                    PushMatrix()
                    loader.rot = Rotate(angle=0)
                with loader.canvas.after:
                    PopMatrix()

                def update_loader_rot(ins, val):
                    ins.rot.origin = ins.center
                loader.bind(center=update_loader_rot)
                
                # Petite rotation interne pour les images
                anim = Animation(angle=-360, duration=1.5, t='linear')
                anim.repeat = True
                anim.start(loader.rot)

                def on_loaded(*args):
                    anim.stop(loader.rot)
                    Animation(opacity=0, duration=0.2).start(loader)
                    Animation(opacity=1, duration=0.3).start(img)
                img.bind(on_load=on_loaded)
                img_container.add_widget(loader)

            self.add_widget(img_container)
        self.bind(minimum_height=self.setter('height'))

    def _update_rect(self, instance, value):
        self.bg_rect.pos = instance.pos
        self.bg_rect.size = instance.size

# --- HOMESCREEN ---
class HomeScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.last_config_hash = None
        self.KIVY_BLUE = (30/255, 58/255, 138/255, 1)

        self.main_layout = FloatLayout() 
        self.container = BoxLayout(orientation="vertical")
        with self.container.canvas.before:
            Color(*self.KIVY_BLUE)
            self.rect_bg = Rectangle(pos=self.container.pos, size=self.container.size)
        self.container.bind(pos=self._update_bg, size=self._update_bg)

        self.scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False, bar_width=0)
        self.scroll_content = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(20), padding=[0, 0, 0, dp(10)])
        self.scroll_content.bind(minimum_height=self.scroll_content.setter('height'))

        self.banner = Image(
            source="assets/banniere.png", size_hint=(1, None), height=dp(200),
            allow_stretch=True, keep_ratio=True
        )
        self.banner.bind(width=lambda inst, val: setattr(inst, 'height', val * 0.5625))
        self.scroll_content.add_widget(self.banner)

        self.news_layout = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(20), padding=[dp(15), 0, dp(15), 0])
        self.news_layout.bind(minimum_height=self.news_layout.setter('height'))
        self.scroll_content.add_widget(self.news_layout)

        self.scroll.add_widget(self.scroll_content)
        self.container.add_widget(self.scroll)
        
        # LOADER PRINCIPAL (Amélioré)
        self.main_loader = Image(
            source="assets/icons/loading_wheel.png", size_hint=(None, None),
            size=(dp(50), dp(50)), pos_hint={'center_x': 0.5, 'center_y': 0.5},
            opacity=0
        )
        with self.main_loader.canvas.before:
            PushMatrix()
            self.main_rot = Rotate(angle=0)
        with self.main_loader.canvas.after:
            PopMatrix()
            
        self.main_loader.bind(center=self._update_rot_origin)

        self.main_layout.add_widget(self.container)
        self.main_layout.add_widget(self.main_loader)
        self.add_widget(self.main_layout)

    def _update_rot_origin(self, instance, value):
        self.main_rot.origin = instance.center

    def _update_bg(self, instance, value):
        self.rect_bg.pos = instance.pos
        self.rect_bg.size = instance.size

    def _rotate_loader(self, dt):
        """ Rotation manuelle insensible aux blocages d'Animation """
        self.main_rot.angle -= 6

    def show_main_loader(self, show):
        if show:
            if self.main_loader.opacity == 0:
                self.main_loader.opacity = 1
                Clock.unschedule(self._rotate_loader)
                Clock.schedule_interval(self._rotate_loader, 1/60)
        else:
            self.main_loader.opacity = 0
            Clock.unschedule(self._rotate_loader)

    def on_enter(self):
        app = App.get_running_app()
        self.last_config_hash = None 
        self.update_ui_from_config()

        def background_check():
            if hasattr(app, 'load_remote_config'):
                app.load_remote_config()
                Clock.schedule_once(lambda dt: self.update_ui_from_config(), 0)
        threading.Thread(target=background_check, daemon=True).start()

    def update_ui_from_config(self, *args):
        app = App.get_running_app()
        if not hasattr(app, "app_config") or not app.app_config:
            self.show_main_loader(True)
            return False

        fcvv_data = app.app_config.get("fcvv", {})
        news_list = fcvv_data.get("appli", {}).get("news", [])
        
        try:
            current_hash = hashlib.md5(json.dumps(news_list, sort_keys=True).encode()).hexdigest()
        except: current_hash = "error"

        if current_hash == self.last_config_hash:
            return False

        self.last_config_hash = current_hash
        self.news_layout.clear_widgets()
        self.show_main_loader(True)

        # On lance la génération après un court délai pour laisser la roue apparaître
        Clock.schedule_once(lambda dt: self._start_gradual_gen(news_list), 0.2)
        return True

    def _start_gradual_gen(self, news_list):
        if not news_list:
            self.show_main_loader(False)
            self.news_layout.add_widget(Label(text="Aucune actualité.", size_hint_y=None, height=dp(100)))
            return

        def add_item(dt, index):
            if index < len(news_list):
                item = news_list[index]
                card = NewsCard(
                    title=item.get("title", ""),
                    date=item.get("date", ""),
                    description=item.get("description", ""),
                    image_url=item.get("image", None)
                )
                
                # 1. On ajoute la carte
                self.news_layout.add_widget(card)
                
                # 2. FORCE LE DESSIN : On demande à Kivy de recalculer le layout immédiatement
                self.news_layout.do_layout()
                
                # 3. On passe à la suivante avec un léger délai
                # On augmente un peu à 0.08s pour laisser le temps au GPU de dessiner la carte
                Clock.schedule_once(lambda d: add_item(d, index + 1), 0.08)
            else:
                # Terminé
                self.show_main_loader(False)

        # Lancement du processus
        add_item(0, 0)