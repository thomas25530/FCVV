# -*- coding: utf-8 -*-
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, RoundedRectangle
from kivy.app import App
from kivy.metrics import dp
from kivy.core.window import Window

class EffectifScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.current_team_index = 0
        self.KIVY_BLUE = (30/255, 58/255, 138/255, 1)

        self.main_layout = BoxLayout(orientation="vertical")
        with self.main_layout.canvas.before:
            Color(*self.KIVY_BLUE)
            self.rect_bg = RoundedRectangle(pos=self.main_layout.pos, size=self.main_layout.size)
        self.main_layout.bind(pos=self._update_bg, size=self._update_bg)

        # --- 1. SÉLECTEUR D'ÉQUIPE (MODIFIÉ POUR GROS DOIGTS) ---
        # Hauteur augmentée de 65 à 85dp
        # --- 1. SÉLECTEUR D'ÉQUIPE ---
        self.team_scroll = ScrollView(
            size_hint=(1, None), 
            height=dp(85), 
            do_scroll_y=False,
            bar_width=0,            # <--- Ajouté
            scroll_type=['content'] # <--- Ajouté
        )
        # Espacement et padding augmentés à 10dp
        self.team_selector = BoxLayout(size_hint_x=None, spacing=dp(10), padding=dp(10))
        self.team_selector.bind(minimum_width=self.team_selector.setter('width'))
        self.team_scroll.add_widget(self.team_selector)
        self.main_layout.add_widget(self.team_scroll)

        # 2. Zone de contenu pour le tableau
        self.table_area = BoxLayout(orientation="vertical", size_hint=(1, 1))
        self.main_layout.add_widget(self.table_area)
        
        self.add_widget(self.main_layout)

    def _update_bg(self, instance, value):
        self.rect_bg.pos = instance.pos
        self.rect_bg.size = instance.size

    def on_enter(self):
        self.update_ui_from_config()

    def update_ui_from_config(self, *args):
        app = App.get_running_app()
        f_factor = 20
        if hasattr(app, 'config'):
            try: f_factor = app.config.getint('User', 'font_size_factor')
            except: pass

        all_effectifs = app.app_config.get("fcvv", {}).get("appli", {}).get("effectifs", [])
        if not all_effectifs: return

        self.team_selector.clear_widgets()
        for i, eff_data in enumerate(all_effectifs):
            is_active = (i == self.current_team_index)
            
            # Largeur de bouton augmentée pour faciliter le clic
            btn_width = max(dp(160), dp(len(eff_data.get("equipe_nom", "")) * (f_factor * 0.7)))
            
            btn = Button(
                text=eff_data.get("equipe_nom", "Équipe"),
                size_hint=(None, 1), # Utilise toute la hauteur du ScrollView (85dp)
                width=btn_width,
                background_normal='',
                background_color=(0.97, 0.93, 0.25, 1) if is_active else (1, 1, 1, 0.15),
                color=(0, 0, 0, 1) if is_active else (1, 1, 1, 1),
                bold=is_active, 
                font_size=f"{f_factor - 1}sp" # Police légèrement plus grande
            )
            
            # Ajout d'un arrondi pour le confort visuel
            with btn.canvas.before:
                Color(*(0.97, 0.93, 0.25, 1) if is_active else (1, 1, 1, 0.15))
                btn.bg_rect = RoundedRectangle(pos=btn.pos, size=btn.size, radius=[dp(8)])
            btn.bind(pos=lambda inst, val: setattr(inst.bg_rect, 'pos', inst.pos),
                     size=lambda inst, val: setattr(inst.bg_rect, 'size', inst.size))

            btn.bind(on_release=lambda x, idx=i: self.switch_team(idx))
            self.team_selector.add_widget(btn)

        self.render_table(all_effectifs[self.current_team_index], f_factor)

    def switch_team(self, index):
        self.current_team_index = index
        self.update_ui_from_config()

    def render_table(self, data, f_factor):
        self.table_area.clear_widgets()
        
        main_scroll = ScrollView(
            size_hint=(1, 1), 
            do_scroll_x=True, 
            do_scroll_y=True,
            bar_width=0,
            scroll_type=['content']
        )
        
        base_widths = [45, 180, 110, 85, 40]
        adjusted_widths = [dp(w + (f_factor - 20) * 1.8) for w in base_widths]
        
        # --- MODIFICATION ICI ---
        # On calcule la largeur minimale nécessaire
        min_needed_width = sum(adjusted_widths)
        # On prend le max entre le besoin du tableau et la largeur réelle de l'écran
        total_table_width = max(min_needed_width, Window.width)
        
        # Si on a étiré le tableau pour remplir l'écran, 
        # on ajuste proportionnellement la colonne "Joueur" (la plus large)
        if total_table_width > min_needed_width:
            diff = total_table_width - min_needed_width
            adjusted_widths[1] += diff 
        # --------------------------

        inner_table = BoxLayout(orientation="vertical", size_hint=(None, None), width=total_table_width)
        inner_table.bind(minimum_height=inner_table.setter('height'))

        # --- HEADER ---
        h_height = dp(45) + dp(f_factor - 20)
        header = GridLayout(cols=5, size_hint=(None, None), height=h_height, width=total_table_width)
        titles = ["N°", "Joueur", "Né(e) le", "Poste", ""]
        
        for i, title in enumerate(titles):
            header.add_widget(Label(
                text=title, bold=True, font_size=f"{f_factor - 6}sp",
                size_hint_x=None, width=adjusted_widths[i]
            ))
        inner_table.add_widget(header)

        # --- LISTE DES JOUEURS ---
        row_height = dp(50) + dp(f_factor - 20)
        for j in data.get("joueurs", []):
            row = GridLayout(cols=5, size_hint=(None, None), height=row_height, width=total_table_width)
            is_cap = j.get("capitaine", False)
            
            with row.canvas.before:
                Color(*(0.97, 0.93, 0.25, 0.25) if is_cap else (1, 1, 1, 0.05))
                row.bg_rect = RoundedRectangle(pos=row.pos, size=(total_table_width, row_height), radius=[dp(5)])
            
            def update_row_bg(inst, val, w=total_table_width, h=row_height):
                inst.bg_rect.pos = inst.pos
                inst.bg_rect.size = (w, h)
            row.bind(pos=update_row_bg)

            row.add_widget(Label(text=str(j.get("numero", "-")), size_hint_x=None, width=adjusted_widths[0], 
                                 font_size=f"{f_factor - 4}sp", color=(0.97, 0.93, 0.25, 1), bold=True))
            
            nom_complet = f"{j.get('nom', '').upper()} {j.get('prenom', '')}"
            row.add_widget(Label(text=nom_complet, size_hint_x=None, width=adjusted_widths[1], 
                                 halign='left', valign='middle', font_size=f"{f_factor - 5}sp",
                                 text_size=(adjusted_widths[1]-dp(10), None)))
            
            row.add_widget(Label(text=j.get("naissance", "-"), size_hint_x=None, width=adjusted_widths[2], 
                                 font_size=f"{f_factor - 7}sp"))
            
            row.add_widget(Label(text=j.get("poste", "-"), size_hint_x=None, width=adjusted_widths[3], 
                                 font_size=f"{f_factor - 8}sp", color=(0.8, 0.8, 0.8, 1)))

            cap_text = "[color=F7EC3F]©[/color]" if is_cap else ""
            row.add_widget(Label(text=cap_text, markup=True, size_hint_x=None, width=adjusted_widths[4], 
                                 font_size=f"{f_factor}sp", bold=True))

            inner_table.add_widget(row)

        main_scroll.add_widget(inner_table)
        self.table_area.add_widget(main_scroll)