# -*- coding: utf-8 -*-
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, RoundedRectangle, Rectangle
from kivy.app import App
from kivy.metrics import dp
from kivy.core.window import Window

class ClassementScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.current_team_index = 0
        self.KIVY_BLUE = (30/255, 58/255, 138/255, 1)

        self.main_layout = BoxLayout(orientation="vertical")
        with self.main_layout.canvas.before:
            Color(*self.KIVY_BLUE)
            self.rect_bg = Rectangle(pos=self.main_layout.pos, size=self.main_layout.size)
        self.main_layout.bind(pos=self._update_bg, size=self._update_bg)

        # 1. Sélecteur d'équipe (Style "Onglets Jolis")
        self.team_scroll = ScrollView(
            size_hint=(1, None), 
            height=dp(85), 
            do_scroll_y=False,
            bar_width=0,
            scroll_type=['content']
        )
        self.team_selector = BoxLayout(size_hint_x=None, spacing=dp(10), padding=dp(10))
        self.team_selector.bind(minimum_width=self.team_selector.setter('width'))
        self.team_scroll.add_widget(self.team_selector)
        self.main_layout.add_widget(self.team_scroll)

        # 2. Zone d'infos
        self.info_bar = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(35), padding=[dp(15), 0])
        self.main_layout.add_widget(self.info_bar)

        # 3. Zone Tableau
        self.table_area = BoxLayout(orientation="vertical", size_hint=(1, 1))
        self.main_layout.add_widget(self.table_area)
        
        self.add_widget(self.main_layout)

    def _update_bg(self, instance, value):
        self.rect_bg.pos = instance.pos
        self.rect_bg.size = instance.size

    def on_enter(self):
        self.update_ui_from_config()

    def update_ui_from_config(self, *args):
        app = App.get_running_app()
        f_factor = 24 # Valeur par défaut
        if hasattr(app, 'config'):
            try: f_factor = app.config.getint('User', 'font_size_factor')
            except: pass

        # Récupération des données depuis fcvv.yaml
        all_classements = app.app_config.get("fcvv", {}).get("appli", {}).get("classements", [])
        if not all_classements: return

        self.team_selector.clear_widgets()
        for i, class_data in enumerate(all_classements):
            is_active = (i == self.current_team_index)
            nom_equipe = class_data.get("equipe_nom", "Équipe")
            
            # --- STYLE ONGLETS HARMONISÉ ---
            btn_width = max(dp(160), dp(len(nom_equipe) * (f_factor * 0.7)))
            
            btn = Button(
                text=nom_equipe,
                size_hint=(None, 1),
                width=btn_width,
                background_normal='',
                background_color=(0, 0, 0, 0), # Transparent
                color=(0, 0, 0, 1) if is_active else (1, 1, 1, 1),
                bold=is_active, 
                font_size=f"{f_factor - 1}sp"
            )
            
            with btn.canvas.before:
                Color(*(0.97, 0.93, 0.25, 1) if is_active else (1, 1, 1, 0.15))
                btn.bg_rect = RoundedRectangle(pos=btn.pos, size=btn.size, radius=[dp(8)])
            
            btn.bind(pos=lambda inst, val: setattr(inst.bg_rect, 'pos', inst.pos),
                     size=lambda inst, val: setattr(inst.bg_rect, 'size', inst.size))

            btn.bind(on_release=lambda x, idx=i: self.switch_team(idx))
            self.team_selector.add_widget(btn)

        if self.current_team_index < len(all_classements):
            self.render_table(all_classements[self.current_team_index], f_factor)

    def switch_team(self, index):
        self.current_team_index = index
        self.update_ui_from_config()

    def render_table(self, data, f_factor):
        self.info_bar.clear_widgets()
        txt_info = f"[b]{data.get('journee', '-')}[/b]  •  MAJ : {data.get('maj', '-')}"
        self.info_bar.add_widget(Label(text=txt_info, markup=True, font_size=f"{f_factor - 5}sp"))

        self.table_area.clear_widgets()
        
        main_scroll = ScrollView(
            size_hint=(1, 1), 
            do_scroll_x=True, 
            do_scroll_y=True,
            bar_width=0,
            scroll_type=['content']
        )
        
        # Colonnes du classement
        col_widths_dp = [40, 180, 45, 35, 35, 35, 35, 35, 40, 40, 35, 45]
        adjusted_widths = [dp(w + (f_factor - 20) * 1.5) for w in col_widths_dp]
        min_table_width = sum(adjusted_widths)

        inner_table = BoxLayout(orientation="vertical", size_hint=(None, None), width=min_table_width)
        inner_table.bind(minimum_height=inner_table.setter('height'))

        # --- HEADER DU TABLEAU ---
        h_height = dp(45) + dp(f_factor - 20)
        header = GridLayout(cols=12, size_hint=(None, None), height=h_height, width=min_table_width)
        
        titles = ["Rg", "Equipe", "Pts", "J", "G", "N", "P", "F", "Bp", "Bc", "Pé", "Diff"]
        for i, title in enumerate(titles):
            header.add_widget(Label(
                text=title, bold=True, font_size=f"{f_factor - 7}sp",
                size_hint_x=None, width=adjusted_widths[i],
                color=(0.97, 0.93, 0.25, 1) # Titres en jaune
            ))
        inner_table.add_widget(header)

        # --- LIGNES DU TABLEAU ---
        row_height = dp(40) + dp(f_factor - 20)
        for entry in data.get("tableau", []):
            row = GridLayout(cols=12, size_hint=(None, None), height=row_height, width=min_table_width)
            
            nom_equipe = entry.get("equipe", "")
            is_club = "Vercel" in nom_equipe or "FCVV" in nom_equipe
            
            with row.canvas.before:
                if is_club:
                    Color(0.97, 0.93, 0.25, 0.3) # Surlignage jaune transparent pour notre club
                else:
                    Color(1, 1, 1, 0.05) # Surlignage léger pour les autres
                
                row.bg_rect = RoundedRectangle(pos=row.pos, size=row.size, radius=[dp(3)])
            
            # Mise à jour du fond lors du défilement
            row.bind(pos=lambda inst, val: setattr(inst.bg_rect, 'pos', inst.pos),
                     size=lambda inst, val: setattr(inst.bg_rect, 'size', inst.size))

            fields = ["rang", "equipe", "pts", "j", "g", "n", "p", "f", "bp", "bc", "pe", "diff"]
            for i, field in enumerate(fields):
                valeur = str(entry.get(field, "0"))
                row.add_widget(Label(
                    text=valeur,
                    font_size=f"{f_factor - 7}sp",
                    size_hint_x=None, 
                    width=adjusted_widths[i],
                    color=(1, 1, 0.6, 1) if is_club else (1, 1, 1, 1),
                    bold=is_club, 
                    halign='center',
                    valign='middle'
                ))
            inner_table.add_widget(row)

        main_scroll.add_widget(inner_table)
        self.table_area.add_widget(main_scroll)