from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Rectangle
from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
import webbrowser
from kivy.uix.button import Button
from kivy.uix.widget import Widget

class InscriptionsScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # 1. ROOT PRINCIPAL
        self.KIVY_BLUE = (30/255, 58/255, 138/255, 1)
        self.container = BoxLayout(orientation="vertical", padding=[dp(15), dp(10), dp(15), dp(10)])
        with self.container.canvas.before:
            Color(*self.KIVY_BLUE)
            self.rect_bg = Rectangle(pos=self.container.pos, size=self.container.size)
        self.container.bind(pos=self._update_bg, size=self._update_bg)

        # 2. SCROLLVIEW VERTICAL
        self.main_scroll = ScrollView(size_hint=(1, 1), do_scroll_x=False)
        self.scroll_content = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(20))
        self.scroll_content.bind(minimum_height=self.scroll_content.setter('height'))

        # --- BOUTON INSCRIPTION ---
        self.inscription_url = ""
        self.inscription_btn = Button(
            text="", markup=True, color=(1, 1, 0, 1),
            background_normal='', background_color=(0, 0, 0, 0),
            size_hint_y=None, height=dp(60)
        )
        self.inscription_btn.bind(on_release=self._on_inscription_click)

        # --- TABLEAU AVEC SCROLL HORIZONTAL ---
        self.h_scroll = ScrollView(
            size_hint=(1, None), 
            do_scroll_y=False, 
            bar_width=0,            # <--- Suppression de l'épaisseur de la barre
            scroll_type=['content'] # <--- Scroll uniquement via le contenu
        )
        
        # Le conteneur du tableau : size_hint_y=None est CRUCIAL ici
        self.table_container = BoxLayout(orientation="vertical", size_hint=(None, None), spacing=dp(2))
        
        # On force la mise à jour de la hauteur du conteneur et du scroll
        self.table_container.bind(minimum_height=self._update_table_height)
        
        self.h_scroll.add_widget(self.table_container)

        # Assemblage
        self.scroll_content.add_widget(BoxLayout(size_hint_y=None, height=dp(10)))
        self.scroll_content.add_widget(self.inscription_btn)
        self.scroll_content.add_widget(self.h_scroll)
        
        self.main_scroll.add_widget(self.scroll_content)
        self.container.add_widget(self.main_scroll)
        self.add_widget(self.container)
        
    def _update_bg(self, instance, value):
        self.rect_bg.pos = instance.pos
        self.rect_bg.size = instance.size

    def _update_table_height(self, instance, value):
        """ Force la hauteur du container et du ScrollView horizontal """
        instance.height = value
        self.h_scroll.height = value + dp(15) # + marge pour la scrollbar

    def on_pre_enter(self):
        # On attend un tout petit peu que le layout soit prêt
        Clock.schedule_once(self.update_ui_from_config, 0.1)

    def update_ui_from_config(self, *args):
        app = App.get_running_app()
        if not hasattr(app, "app_config") or not app.app_config:
            return

        # --- CONFIG POLICE ET LANGUE ---
        lang = "Français"
        user_font_size = 20
        if hasattr(app, 'config') and app.config.has_section('User'):
            user_font_size = app.config.getint('User', 'font_size_factor')
            lang = app.config.get('User', 'langue')
        
        base_fs = user_font_size - 4
        row_height = dp(user_font_size * 2.5)

        # Largeurs de colonnes
        col_unit = dp(user_font_size * 3.5) 
        col_tournoi = col_unit * 2.5
        col_date = col_unit * 1.5
        col_prix = col_unit * 1.2
        
        total_table_width = col_tournoi + col_date + (col_prix * 3)
        self.table_container.width = total_table_width

        # --- RÉCUPÉRATION DES DONNÉES ---
        # On va chercher l'URL dans 'home' comme dans home.py
        home_data = app.app_config.get("tournoi", {}).get("appli", {}).get("home", {})
        # On garde les tarifs dans 'inscriptions'
        inscriptions_data = app.app_config.get("tournoi", {}).get("appli", {}).get("inscriptions", {})

        # 1. GESTION DU BOUTON INSCRIPTION (Source: home_data)
        url = home_data.get("inscription_url", "") # Récupération identique à home.py
        if url:
            self.inscription_url = url
            self.inscription_btn.font_size = f"{user_font_size * 0.8}sp"
            self.inscription_btn.text = (
                "[u][b]*** CLICK HERE FOR ONLINE REGISTRATION ***[/b][/u]" 
                if lang == "English" 
                else "[u][b]*** CLIQUEZ ICI POUR L'INSCRIPTION EN LIGNE ***[/b][/u]"
            )
            self.inscription_btn.height = dp(70)
            self.inscription_btn.opacity = 1
            self.inscription_btn.disabled = False
        else:
            self.inscription_url = ""
            self.inscription_btn.text = ""
            self.inscription_btn.height = 0
            self.inscription_btn.opacity = 0
            self.inscription_btn.disabled = True

        # 2. CONSTRUCTION DU TABLEAU (Source: inscriptions_data)
        self.table_container.clear_widgets()
        tarifs = inscriptions_data.get("tarifs", [])

        if tarifs:
            gap = dp(2) 

            # --- LIGNE 1 : TARIFS (CHAPEAU) ---
            top_header = BoxLayout(size_hint=(None, None), height=row_height*0.7, width=total_table_width, spacing=gap)
            spacer_w = col_tournoi + gap + col_date
            top_header.add_widget(Widget(size_hint=(None, 1), width=spacer_w))
            
            tarif_label_w = col_prix + gap + col_prix + gap + col_prix
            t_label = self._create_cell("TARIFS", font_size=base_fs+2, is_header=True, bg_color=(0.9, 0.8, 0, 1))
            t_label.size_hint = (None, 1)
            t_label.width = tarif_label_w
            top_header.add_widget(t_label)
            self.table_container.add_widget(top_header)

            # --- LIGNE 2 : EN-TÊTE COLONNES ---
            header_box = BoxLayout(size_hint=(None, None), height=row_height, width=total_table_width, spacing=gap)
            cols = [
                ("Tournoi", col_tournoi), 
                ("Date", col_date), 
                ("1 éq.", col_prix), 
                ("2 éq.", col_prix), 
                ("3 éq.", col_prix)
            ]
            for text, w in cols:
                cell = self._create_cell(text, font_size=base_fs, is_header=True)
                cell.size_hint = (None, 1)
                cell.width = w
                header_box.add_widget(cell)
            self.table_container.add_widget(header_box)

            # --- LIGNES DE DONNÉES ---
            for t in tarifs:
                row = BoxLayout(size_hint=(None, None), height=row_height, width=total_table_width, spacing=gap)
                # Remplace la section des prix par celle-ci pour un rendu parfait :
                vals = [
                    (str(t.get("nom", "")), col_tournoi), 
                    (str(t.get("date", "")), col_date), 
                    (f"{t.get('prix1')}€" if t.get('prix1') else "-", col_prix), 
                    (f"{t.get('prix2')}€" if t.get('prix2') else "-", col_prix), 
                    (f"{t.get('prix3')}€" if t.get('prix3') else "-", col_prix)
                ]
                for text, w in vals:
                    c = self._create_cell(text, font_size=base_fs)
                    c.size_hint = (None, 1)
                    c.width = w
                    row.add_widget(c)
                self.table_container.add_widget(row)
                

    def _create_cell(self, text, font_size=14, is_header=False, bg_color=None):
        lbl = Label(
            text=text, font_size=f"{font_size}sp", bold=is_header,
            color=(0, 0, 0, 1) if is_header else (1, 1, 1, 1),
            halign='center', valign='middle'
        )
        if not bg_color:
            color = (0.97, 0.92, 0.25, 1) if is_header else (1, 1, 1, 0.1)
        else: color = bg_color

        with lbl.canvas.before:
            Color(*color)
            lbl.rect = Rectangle(pos=lbl.pos, size=lbl.size)
        lbl.bind(pos=self._update_cell_rect, size=self._update_cell_rect)
        return lbl

    def _update_cell_rect(self, instance, value):
        instance.rect.pos = instance.pos
        instance.rect.size = instance.size

    def _on_inscription_click(self, instance):
        if self.inscription_url:
            webbrowser.open(self.inscription_url)